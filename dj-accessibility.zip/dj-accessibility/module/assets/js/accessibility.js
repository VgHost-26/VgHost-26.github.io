"use strict";
function _typeof(t) {
    return (_typeof =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (t) {
                  return typeof t;
              }
            : function (t) {
                  return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
              })(t);
}
function _createForOfIteratorHelper(t, e) {
    var n = ("undefined" != typeof Symbol && t[Symbol.iterator]) || t["@@iterator"];
    if (!n) {
        if (Array.isArray(t) || (n = _unsupportedIterableToArray(t)) || (e && t && "number" == typeof t.length)) {
            n && (t = n);
            var r = 0,
                a = function () {};
            return {
                s: a,
                n: function () {
                    return r >= t.length ? { done: !0 } : { done: !1, value: t[r++] };
                },
                e: function (t) {
                    throw t;
                },
                f: a,
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var i,
        c = !0,
        o = !1;
    return {
        s: function () {
            n = n.call(t);
        },
        n: function () {
            var t = n.next();
            return (c = t.done), t;
        },
        e: function (t) {
            (o = !0), (i = t);
        },
        f: function () {
            try {
                c || null == n.return || n.return();
            } finally {
                if (o) throw i;
            }
        },
    };
}
function _toConsumableArray(t) {
    return _arrayWithoutHoles(t) || _iterableToArray(t) || _unsupportedIterableToArray(t) || _nonIterableSpread();
}
function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(t, e) {
    if (t) {
        if ("string" == typeof t) return _arrayLikeToArray(t, e);
        var n = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? _arrayLikeToArray(t, e) : void 0;
    }
}
function _iterableToArray(t) {
    if (("undefined" != typeof Symbol && null != t[Symbol.iterator]) || null != t["@@iterator"]) return Array.from(t);
}
function _arrayWithoutHoles(t) {
    if (Array.isArray(t)) return _arrayLikeToArray(t);
}
function _arrayLikeToArray(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
    return r;
}
function _regeneratorRuntime() {
    _regeneratorRuntime = function () {
        return t;
    };
    var t = {},
        e = Object.prototype,
        n = e.hasOwnProperty,
        r =
            Object.defineProperty ||
            function (t, e, n) {
                t[e] = n.value;
            },
        a = "function" == typeof Symbol ? Symbol : {},
        i = a.iterator || "@@iterator",
        c = a.asyncIterator || "@@asyncIterator",
        o = a.toStringTag || "@@toStringTag";
    function s(t, e, n) {
        return Object.defineProperty(t, e, { value: n, enumerable: !0, configurable: !0, writable: !0 }), t[e];
    }
    try {
        s({}, "");
    } catch (t) {
        s = function (t, e, n) {
            return (t[e] = n);
        };
    }
    function l(t, e, n, a) {
        var i = e && e.prototype instanceof h ? e : h,
            c = Object.create(i.prototype),
            o = new w(a || []);
        return r(c, "_invoke", { value: L(t, n, o) }), c;
    }
    function d(t, e, n) {
        try {
            return { type: "normal", arg: t.call(e, n) };
        } catch (t) {
            return { type: "throw", arg: t };
        }
    }
    t.wrap = l;
    var u = {};
    function h() {}
    function f() {}
    function p() {}
    var v = {};
    s(v, i, function () {
        return this;
    });
    var y = Object.getPrototypeOf,
        g = y && y(y(E([])));
    g && g !== e && n.call(g, i) && (v = g);
    var m = (p.prototype = h.prototype = Object.create(v));
    function _(t) {
        ["next", "throw", "return"].forEach(function (e) {
            s(t, e, function (t) {
                return this._invoke(e, t);
            });
        });
    }
    function j(t, e) {
        var a;
        r(this, "_invoke", {
            value: function (r, i) {
                function c() {
                    return new e(function (a, c) {
                        !(function r(a, i, c, o) {
                            var s = d(t[a], t, i);
                            if ("throw" !== s.type) {
                                var l = s.arg,
                                    u = l.value;
                                return u && "object" == _typeof(u) && n.call(u, "__await")
                                    ? e.resolve(u.__await).then(
                                          function (t) {
                                              r("next", t, c, o);
                                          },
                                          function (t) {
                                              r("throw", t, c, o);
                                          }
                                      )
                                    : e.resolve(u).then(
                                          function (t) {
                                              (l.value = t), c(l);
                                          },
                                          function (t) {
                                              return r("throw", t, c, o);
                                          }
                                      );
                            }
                            o(s.arg);
                        })(r, i, a, c);
                    });
                }
                return (a = a ? a.then(c, c) : c());
            },
        });
    }
    function L(t, e, n) {
        var r = "suspendedStart";
        return function (a, i) {
            if ("executing" === r) throw new Error("Generator is already running");
            if ("completed" === r) {
                if ("throw" === a) throw i;
                return x();
            }
            for (n.method = a, n.arg = i; ; ) {
                var c = n.delegate;
                if (c) {
                    var o = b(c, n);
                    if (o) {
                        if (o === u) continue;
                        return o;
                    }
                }
                if ("next" === n.method) n.sent = n._sent = n.arg;
                else if ("throw" === n.method) {
                    if ("suspendedStart" === r) throw ((r = "completed"), n.arg);
                    n.dispatchException(n.arg);
                } else "return" === n.method && n.abrupt("return", n.arg);
                r = "executing";
                var s = d(t, e, n);
                if ("normal" === s.type) {
                    if (((r = n.done ? "completed" : "suspendedYield"), s.arg === u)) continue;
                    return { value: s.arg, done: n.done };
                }
                "throw" === s.type && ((r = "completed"), (n.method = "throw"), (n.arg = s.arg));
            }
        };
    }
    function b(t, e) {
        var n = t.iterator[e.method];
        if (void 0 === n) {
            if (((e.delegate = null), "throw" === e.method)) {
                if (t.iterator.return && ((e.method = "return"), (e.arg = void 0), b(t, e), "throw" === e.method)) return u;
                (e.method = "throw"), (e.arg = new TypeError("The iterator does not provide a 'throw' method"));
            }
            return u;
        }
        var r = d(n, t.iterator, e.arg);
        if ("throw" === r.type) return (e.method = "throw"), (e.arg = r.arg), (e.delegate = null), u;
        var a = r.arg;
        return a
            ? a.done
                ? ((e[t.resultName] = a.value), (e.next = t.nextLoc), "return" !== e.method && ((e.method = "next"), (e.arg = void 0)), (e.delegate = null), u)
                : a
            : ((e.method = "throw"), (e.arg = new TypeError("iterator result is not an object")), (e.delegate = null), u);
    }
    function k(t) {
        var e = { tryLoc: t[0] };
        1 in t && (e.catchLoc = t[1]), 2 in t && ((e.finallyLoc = t[2]), (e.afterLoc = t[3])), this.tryEntries.push(e);
    }
    function S(t) {
        var e = t.completion || {};
        (e.type = "normal"), delete e.arg, (t.completion = e);
    }
    function w(t) {
        (this.tryEntries = [{ tryLoc: "root" }]), t.forEach(k, this), this.reset(!0);
    }
    function E(t) {
        if (t) {
            var e = t[i];
            if (e) return e.call(t);
            if ("function" == typeof t.next) return t;
            if (!isNaN(t.length)) {
                var r = -1,
                    a = function e() {
                        for (; ++r < t.length; ) if (n.call(t, r)) return (e.value = t[r]), (e.done = !1), e;
                        return (e.value = void 0), (e.done = !0), e;
                    };
                return (a.next = a);
            }
        }
        return { next: x };
    }
    function x() {
        return { value: void 0, done: !0 };
    }
    return (
        (f.prototype = p),
        r(m, "constructor", { value: p, configurable: !0 }),
        r(p, "constructor", { value: f, configurable: !0 }),
        (f.displayName = s(p, o, "GeneratorFunction")),
        (t.isGeneratorFunction = function (t) {
            var e = "function" == typeof t && t.constructor;
            return !!e && (e === f || "GeneratorFunction" === (e.displayName || e.name));
        }),
        (t.mark = function (t) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(t, p) : ((t.__proto__ = p), s(t, o, "GeneratorFunction")), (t.prototype = Object.create(m)), t;
        }),
        (t.awrap = function (t) {
            return { __await: t };
        }),
        _(j.prototype),
        s(j.prototype, c, function () {
            return this;
        }),
        (t.AsyncIterator = j),
        (t.async = function (e, n, r, a, i) {
            void 0 === i && (i = Promise);
            var c = new j(l(e, n, r, a), i);
            return t.isGeneratorFunction(n)
                ? c
                : c.next().then(function (t) {
                      return t.done ? t.value : c.next();
                  });
        }),
        _(m),
        s(m, o, "Generator"),
        s(m, i, function () {
            return this;
        }),
        s(m, "toString", function () {
            return "[object Generator]";
        }),
        (t.keys = function (t) {
            var e = Object(t),
                n = [];
            for (var r in e) n.push(r);
            return (
                n.reverse(),
                function t() {
                    for (; n.length; ) {
                        var r = n.pop();
                        if (r in e) return (t.value = r), (t.done = !1), t;
                    }
                    return (t.done = !0), t;
                }
            );
        }),
        (t.values = E),
        (w.prototype = {
            constructor: w,
            reset: function (t) {
                if (((this.prev = 0), (this.next = 0), (this.sent = this._sent = void 0), (this.done = !1), (this.delegate = null), (this.method = "next"), (this.arg = void 0), this.tryEntries.forEach(S), !t))
                    for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0);
            },
            stop: function () {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval;
            },
            dispatchException: function (t) {
                if (this.done) throw t;
                var e = this;
                function r(n, r) {
                    return (c.type = "throw"), (c.arg = t), (e.next = n), r && ((e.method = "next"), (e.arg = void 0)), !!r;
                }
                for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                    var i = this.tryEntries[a],
                        c = i.completion;
                    if ("root" === i.tryLoc) return r("end");
                    if (i.tryLoc <= this.prev) {
                        var o = n.call(i, "catchLoc"),
                            s = n.call(i, "finallyLoc");
                        if (o && s) {
                            if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                            if (this.prev < i.finallyLoc) return r(i.finallyLoc);
                        } else if (o) {
                            if (this.prev < i.catchLoc) return r(i.catchLoc, !0);
                        } else {
                            if (!s) throw new Error("try statement without catch or finally");
                            if (this.prev < i.finallyLoc) return r(i.finallyLoc);
                        }
                    }
                }
            },
            abrupt: function (t, e) {
                for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                    var a = this.tryEntries[r];
                    if (a.tryLoc <= this.prev && n.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                        var i = a;
                        break;
                    }
                }
                i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                var c = i ? i.completion : {};
                return (c.type = t), (c.arg = e), i ? ((this.method = "next"), (this.next = i.finallyLoc), u) : this.complete(c);
            },
            complete: function (t, e) {
                if ("throw" === t.type) throw t.arg;
                return (
                    "break" === t.type || "continue" === t.type ? (this.next = t.arg) : "return" === t.type ? ((this.rval = this.arg = t.arg), (this.method = "return"), (this.next = "end")) : "normal" === t.type && e && (this.next = e), u
                );
            },
            finish: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var n = this.tryEntries[e];
                    if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), S(n), u;
                }
            },
            catch: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var n = this.tryEntries[e];
                    if (n.tryLoc === t) {
                        var r = n.completion;
                        if ("throw" === r.type) {
                            var a = r.arg;
                            S(n);
                        }
                        return a;
                    }
                }
                throw new Error("illegal catch attempt");
            },
            delegateYield: function (t, e, n) {
                return (this.delegate = { iterator: E(t), resultName: e, nextLoc: n }), "next" === this.method && (this.arg = void 0), u;
            },
        }),
        t
    );
}
function asyncGeneratorStep(t, e, n, r, a, i, c) {
    try {
        var o = t[i](c),
            s = o.value;
    } catch (t) {
        return void n(t);
    }
    o.done ? e(s) : Promise.resolve(s).then(r, a);
}
function _asyncToGenerator(t) {
    return function () {
        var e = this,
            n = arguments;
        return new Promise(function (r, a) {
            var i = t.apply(e, n);
            function c(t) {
                asyncGeneratorStep(i, r, a, c, o, "next", t);
            }
            function o(t) {
                asyncGeneratorStep(i, r, a, c, o, "throw", t);
            }
            c(void 0);
        });
    };
}
function ownKeys(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e &&
            (r = r.filter(function (e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            n.push.apply(n, r);
    }
    return n;
}
function _objectSpread(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = null != arguments[e] ? arguments[e] : {};
        e % 2
            ? ownKeys(Object(n), !0).forEach(function (e) {
                  _defineProperty(t, e, n[e]);
              })
            : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n))
            : ownKeys(Object(n)).forEach(function (e) {
                  Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
              });
    }
    return t;
}
function _defineProperty(t, e, n) {
    return e in t ? Object.defineProperty(t, e, { value: n, enumerable: !0, configurable: !0, writable: !0 }) : (t[e] = n), t;
}
function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(t, e) {
    for (var n = 0; n < e.length; n++) {
        var r = e[n];
        (r.enumerable = r.enumerable || !1), (r.configurable = !0), "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r);
    }
}
function _createClass(t, e, n) {
    return e && _defineProperties(t.prototype, e), n && _defineProperties(t, n), Object.defineProperty(t, "prototype", { writable: !1 }), t;
}
var DJAccessibility = (function () {
    function t(e) {
        _classCallCheck(this, t);
        (this.options = _objectSpread(_objectSpread({}, { target: "#djacc" }), e)), (this.page = document.documentElement), (this.state = {}), (this.nodes = {}), (this.textNodes = {}), (this.ver = this.getVersion()), this.init();
    }
    return (
        _createClass(t, [
            {
                key: "init",
                value: function () {
                    var t = this;
                    document.addEventListener("DOMContentLoaded", function () {
                        (t.container = document.querySelector(".djacc")), t.container ? t.showPanel() : t.ajaxLoad();
                    });
                },
            },
            {
                key: "showPanel",
                value: function () {
                    var t = this;
                    t.container &&
                        ((t.panel = t.container.querySelector(".djacc__panel")),
                        t.registerEvents(),
                        t.parseURL(),
                        t.setVersion(),
                        t.container.classList.contains("djacc--custom")
                            ? t.setStaticPosition()
                            : (t.container.classList.remove("djacc--hidden"),
                              t.setPanelSize(),
                              t.reserveSpace(),
                              t.setMobilePosition(),
                              t.updateDirection(),
                              window.addEventListener("resize", function (e) {
                                  t.setPanelSize(), t.reserveSpace(), t.setMobilePosition();
                              })),
                        window.addEventListener("resize", function (e) {
                            t.updateDirection();
                        }));
                },
            },
            {
                key: "ajaxLoad",
                value: (function () {
                    var t = _asyncToGenerator(
                        _regeneratorRuntime().mark(function t() {
                            var e, n, r;
                            return _regeneratorRuntime().wrap(
                                function (t) {
                                    for (;;)
                                        switch ((t.prev = t.next)) {
                                            case 0:
                                                if (this.options.ajax_url) {
                                                    t.next = 2;
                                                    break;
                                                }
                                                return t.abrupt("return");
                                            case 2:
                                                return (e = new FormData()).append("action", this.options.ajax_action), (t.next = 6), fetch(this.options.ajax_url, { method: "POST", credentials: "same-origin", body: e });
                                            case 6:
                                                return (n = t.sent), (t.next = 9), n.text();
                                            case 9:
                                                (r = t.sent), 200 === n.status && (document.body.insertAdjacentHTML("afterbegin", r), (this.container = document.querySelector(".djacc")), this.showPanel());
                                            case 11:
                                            case "end":
                                                return t.stop();
                                        }
                                },
                                t,
                                this
                            );
                        })
                    );
                    return function () {
                        return t.apply(this, arguments);
                    };
                })(),
            },
            {
                key: "parseURL",
                value: function () {
                    if (window.location.hash) {
                        var t = window.location.hash.substring(1);
                        t.replace("djacc-", "", t);
                        var e = document.querySelector(".djacc__btn--" + t);
                        e && e.click();
                    }
                },
            },
            {
                key: "setStaticPosition",
                value: function () {
                    var t = this.options.target,
                        e = document.querySelector(t);
                    e && (this.container.classList.remove("djacc--hidden"), this.container.classList.add("djacc--static"), e.append(this.container));
                },
            },
            {
                key: "addState",
                value: function (t, e) {
                    (this.state[t] = e), this.saveCookie(this.state);
                },
            },
            {
                key: "removeState",
                value: function (t) {
                    delete this.state[t], 0 === Object.keys(this.state).length ? this.removeCookie() : this.saveCookie(this.state);
                },
            },
            {
                key: "setState",
                value: function () {
                    var t = this.getCookie();
                    if (t)
                        for (var e in (t = JSON.parse(t)))
                            if ("contrast" === e || "links" === e || "titles" === e || "sr" === e) {
                                var n = t[e],
                                    r = document.querySelector(".djacc__btn.djacc__btn--" + n);
                                r && r.click();
                            } else {
                                var a = document.querySelector(".djacc__arrows.djacc__arrows--" + e);
                                if (a) for (var i = t[e], c = a.querySelector(".djacc__inc"), o = a.querySelector(".djacc__dec"), s = 0; s < Math.abs(i); s++) i < 0 ? o.click() : c.click();
                            }
                },
            },
            {
                key: "setPanelSize",
                value: function () {
                    if (!this.container.classList.contains("djacc--static")) {
                        var t,
                            e = this.panel.getBoundingClientRect();
                        if (this.container.classList.contains("djacc--bottom-left") || this.container.classList.contains("djacc--bottom-right") || this.container.classList.contains("djacc--bottom-center")) {
                            var n = window.screen.height - e.bottom;
                            t = window.screen.height - n;
                        } else t = window.screen.height - e.top;
                        t > 0 && (this.container.classList.contains("djacc-toolbar") ? (this.panel.querySelector(".djacc__list").style.maxHeight = t + "px") : (this.panel.style.maxHeight = t + "px"));
                    }
                },
            },
            {
                key: "reserveSpace",
                value: function () {
                    if (!this.container.classList.contains("djacc--static") && this.container.classList.contains("djacc-toolbar") && 0 != this.options.space) {
                        var t = this.panel.querySelector(".djacc__list"),
                            e = window.getComputedStyle(this.container),
                            n = t.scrollWidth,
                            r = parseInt(e.marginLeft),
                            a = t.scrollHeight,
                            i = parseInt(e.marginTop);
                        this.container.classList.contains("djacc--center-left")
                            ? (document.body.style.paddingLeft = n + r + "px")
                            : this.container.classList.contains("djacc--center-right")
                            ? (document.body.style.paddingRight = n + r + "px")
                            : this.container.classList.contains("djacc--top-left") || this.container.classList.contains("djacc--top-right") || this.container.classList.contains("djacc--top-center")
                            ? (document.body.style.paddingTop = a + i + "px")
                            : (document.body.style.paddingBottom = a + i + "px");
                    }
                },
            },
            {
                key: "updateDirection",
                value: function () {
                    if (!this.container.classList.contains("djacc-toolbar")) {
                        var t = this.panel.getBoundingClientRect();
                        (this.container.classList.contains("djacc--top-right") || this.container.classList.contains("djacc--bottom-right")) &&
                            (t.left < 0 ? this.container.classList.add("djacc--direction") : this.container.classList.contains("djacc--direction") && this.container.classList.remove("djacc--direction")),
                            (this.container.classList.contains("djacc--top-left") || this.container.classList.contains("djacc--bottom-left")) &&
                                (window.innerWidth < t.right ? this.container.classList.add("djacc--direction") : this.container.classList.contains("djacc--direction") && this.container.classList.remove("djacc--direction"));
                    }
                },
            },
            {
                key: "setMobilePosition",
                value: function () {
                    if (!this.container.classList.contains("djacc--static") && !this.container.classList.contains("djacc-toolbar") && 0 != this.options.align_mobile) {
                        var t = this.options.yootheme ? getComputedStyle(document.body).getPropertyValue("--uk-breakpoint-s").slice(0, -2) : this.options.breakpoint,
                            e = parseInt(t),
                            n = window.innerWidth,
                            r = "djacc--" + this.options.align_position.replace(" ", "-"),
                            a = "djacc--" + this.options.align_mobile_position.replace(" ", "-");
                        n <= e
                            ? this.container.classList.contains(r) && (this.container.classList.add(a), this.container.classList.remove(r))
                            : this.container.classList.contains(a) && (this.container.classList.add(r), this.container.classList.remove(a));
                    }
                },
            },
            {
                key: "registerEvents",
                value: function () {
                    var t = this,
                        e = document.querySelector(".djacc__openbtn");
                    e &&
                        e.addEventListener("click", function (e) {
                            t.panel.classList.toggle("djacc__panel--active"), this.classList.toggle("djacc__openbtn--active"), t.page.classList.toggle("djacc-opened");
                        });
                    var n = function (t) {
                            t.classList.contains("djacc__btn--active")
                                ? t.classList.remove("djacc__btn--active")
                                : (_toConsumableArray(document.querySelectorAll(".djacc__item--contrast > .djacc__btn")).forEach(function (t) {
                                      return t.classList.remove("djacc__btn--active");
                                  }),
                                  t.classList.add("djacc__btn--active"));
                        },
                        r = document.querySelector(".djacc__close");
                    if (
                        r &&
                        (r.addEventListener("click", function (n) {
                            t.panel.classList.remove("djacc__panel--active"), e && e.classList.remove("djacc__openbtn--active"), t.page.classList.remove("djacc-opened");
                        }),
                        !t.container.classList.contains("djacc--toolbar"))
                    ) {
                        var a = t.panel.querySelectorAll('button, [href], input, [tabindex="0"]'),
                            i = a[0],
                            c = a[a.length - 1];
                        i.addEventListener("keydown", function (t) {
                            "Tab" === t.key &&
                                t.shiftKey &&
                                setTimeout(function () {
                                    r.click(), e.focus();
                                }, 300);
                        }),
                            c.addEventListener("keydown", function (t) {
                                "Tab" !== t.key ||
                                    t.shiftKey ||
                                    setTimeout(function () {
                                        r.click(), e.focus();
                                    }, 300);
                            }),
                            document.addEventListener("keyup", function (e) {
                                ("Escape" != e.key && "Esc" != e.key) ||
                                    !t.page.classList.contains("djacc-opened") ||
                                    setTimeout(function () {
                                        r.click();
                                    }, 300);
                            });
                    }
                    var o = document.querySelector(".djacc__reset");
                    o &&
                        o.addEventListener("click", function (e) {
                            var n,
                                r = _createForOfIteratorHelper(document.querySelectorAll(".djacc__item > .djacc__btn, .djacc__item > .djacc__arrows"));
                            try {
                                for (r.s(); !(n = r.n()).done; ) {
                                    var a = n.value;
                                    a.classList.remove("djacc__btn--active"), a.classList.remove("djacc__arrows--active");
                                }
                            } catch (t) {
                                r.e(t);
                            } finally {
                                r.f();
                            }
                            var i,
                                c = _createForOfIteratorHelper(document.querySelectorAll(".djacc__size"));
                            try {
                                for (c.s(); !(i = c.n()).done; ) {
                                    var o = i.value;
                                    (o.innerHTML = "100%"), o.parentNode.removeAttribute("data-djacc-count");
                                }
                            } catch (t) {
                                c.e(t);
                            } finally {
                                c.f();
                            }
                            (t.page.style.filter = ""),
                                (t.page.style.zoom = ""),
                                t.removeCookie(),
                                t.page.classList.contains("djacc-font-size") && t.updateTextStyle("font-size"),
                                t.page.classList.contains("djacc-line-height") && t.updateTextStyle("line-height"),
                                t.page.classList.contains("djacc-letter-spacing") && t.updateTextStyle("letter-spacing"),
                                t.page.classList.contains("djacc-highlight-links") && t.updateLinks(),
                                t.page.classList.contains("djacc-highlight-titles") && t.updateTitles(),
                                t.page.classList.contains("djacc-screen-reader") && t.screenReader(),
                                t.clearClasses(),
                                t.page.classList.contains("djacc-read-mode") && window.location.reload(!1);
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--invert-colors").addEventListener("click", function (e) {
                            n(this), t.contrastInvert();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--monochrome").addEventListener("click", function (e) {
                            n(this), t.contrastMono();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--low-saturation").addEventListener("click", function (e) {
                            n(this), t.contrastLowSaturation();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--high-saturation").addEventListener("click", function (e) {
                            n(this), t.contrastHighSaturation();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--dark-contrast").addEventListener("click", function (e) {
                            n(this), t.contrastDark();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--light-contrast").addEventListener("click", function (e) {
                            n(this), t.contrastLight();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--highlight-links").addEventListener("click", function (e) {
                            this.classList.toggle("djacc__btn--active"), t.highlightLinks();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--highlight-titles").addEventListener("click", function (e) {
                            this.classList.toggle("djacc__btn--active"), t.highlightTitles();
                        }),
                        document.querySelector(".djacc__btn.djacc__btn--read-mode").addEventListener("click", function (e) {
                            this.classList.toggle("djacc__btn--active"), t.readMode();
                        });
                    var s = document.querySelector(".djacc__btn.djacc__btn--screen-reader");
                    "speechSynthesis" in window
                        ? s.addEventListener("click", function (e) {
                              this.classList.toggle("djacc__btn--active"), t.screenReader();
                          })
                        : s.remove(),
                        document.querySelector(".djacc__arrows--zoom .djacc__inc").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "+");
                            t.zoomPage(n);
                        }),
                        document.querySelector(".djacc__arrows--zoom .djacc__dec").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "-");
                            t.zoomPage(n);
                        }),
                        document.querySelector(".djacc__arrows--font-size .djacc__inc").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "+");
                            t.updateTextStyle("font-size", n);
                        }),
                        document.querySelector(".djacc__arrows--font-size .djacc__dec").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "-");
                            t.updateTextStyle("font-size", n);
                        }),
                        document.querySelector(".djacc__arrows--line-height .djacc__inc").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "+");
                            t.updateTextStyle("line-height", n);
                        }),
                        document.querySelector(".djacc__arrows--line-height .djacc__dec").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "-");
                            t.updateTextStyle("line-height", n);
                        }),
                        document.querySelector(".djacc__arrows--letter-spacing .djacc__inc").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "+");
                            t.updateTextStyle("letter-spacing", n);
                        }),
                        document.querySelector(".djacc__arrows--letter-spacing .djacc__dec").addEventListener("click", function (e) {
                            var n = t.countClicks(this.parentNode, "-");
                            t.updateTextStyle("letter-spacing", n);
                        }),
                        this.setState();
                },
            },
            {
                key: "contrastInvert",
                value: function () {
                    this.page.classList.contains("djacc-invert-colors")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-invert-colors"), (this.page.style.filter = ""))
                        : (this.clearContrast(), this.addState("contrast", "invert-colors"), this.page.classList.add("djacc-invert-colors"), (this.page.style.filter = "invert(100%)"));
                },
            },
            {
                key: "contrastMono",
                value: function () {
                    this.page.classList.contains("djacc-monochrome")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-monochrome"), (this.page.style.filter = ""))
                        : (this.clearContrast(), this.addState("contrast", "monochrome"), this.page.classList.add("djacc-monochrome"), (this.page.style.filter = "grayscale(100%)"));
                },
            },
            {
                key: "contrastLowSaturation",
                value: function () {
                    this.page.classList.contains("djacc-low-saturation")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-low-saturation"), (this.page.style.filter = ""))
                        : (this.clearContrast(), this.addState("contrast", "low-saturation"), this.page.classList.add("djacc-low-saturation"), (this.page.style.filter = "saturate(50%)"));
                },
            },
            {
                key: "contrastHighSaturation",
                value: function () {
                    this.page.classList.contains("djacc-high-saturation")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-high-saturation"), (this.page.style.filter = ""))
                        : (this.clearContrast(), this.addState("contrast", "high-saturation"), this.page.classList.add("djacc-high-saturation"), (this.page.style.filter = "saturate(200%)"));
                },
            },
            {
                key: "contrastDark",
                value: function () {
                    this.page.classList.contains("djacc-dark-contrast")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-dark-contrast"), this.updateContrastElements())
                        : (this.clearContrast(), this.addState("contrast", "dark-contrast"), this.page.classList.add("djacc-dark-contrast"), this.updateContrastElements(1));
                },
            },
            {
                key: "contrastLight",
                value: function () {
                    this.page.classList.contains("djacc-light-contrast")
                        ? (this.removeState("contrast"), this.page.classList.remove("djacc-light-contrast"), this.updateContrastElements())
                        : (this.clearContrast(), this.addState("contrast", "light-contrast"), this.page.classList.add("djacc-light-contrast"), this.updateContrastElements(1));
                },
            },
            {
                key: "highlightLinks",
                value: function () {
                    this.page.classList.contains("djacc-highlight-links")
                        ? (this.removeState("links"), this.page.classList.remove("djacc-highlight-links"), this.updateLinks())
                        : (this.addState("links", "highlight-links"), this.page.classList.add("djacc-highlight-links"), this.updateLinks(1));
                },
            },
            {
                key: "highlightTitles",
                value: function () {
                    this.page.classList.contains("djacc-highlight-titles")
                        ? (this.removeState("titles"), this.page.classList.remove("djacc-highlight-titles"), this.updateTitles())
                        : (this.addState("titles", "highlight-titles"), this.page.classList.add("djacc-highlight-titles"), this.updateTitles(1));
                },
            },
            {
                key: "readMode",
                value: function () {
                    if (this.page.classList.contains("djacc-read-mode")) window.location.reload(!1);
                    else {
                        this.page.classList.add("djacc-read-mode");
                        var t,
                            e = _createForOfIteratorHelper(document.querySelectorAll("nav, header, footer, aside, iframe, canvas, img, form, [uk-modal], [uk-sticky], .uk-slider"));
                        try {
                            for (e.s(); !(t = e.n()).done; ) {
                                t.value.remove();
                            }
                        } catch (t) {
                            e.e(t);
                        } finally {
                            e.f();
                        }
                        var n,
                            r = _createForOfIteratorHelper(this.getNodes("readmode"));
                        try {
                            for (r.s(); !(n = r.n()).done; ) {
                                var a = n.value;
                                a.removeAttribute("style"),
                                    a.removeAttribute("id"),
                                    a.removeAttribute("class"),
                                    a.removeAttribute("uk-scrollspy"),
                                    a.removeAttribute("uk-grid"),
                                    a.removeAttribute("uk-img"),
                                    a.removeAttribute("uk-parallax"),
                                    a.removeAttribute("uk-scrollspy-class"),
                                    a.removeAttribute("uk-filter");
                            }
                        } catch (t) {
                            r.e(t);
                        } finally {
                            r.f();
                        }
                    }
                },
            },
            {
                key: "screenReader",
                value: function () {
                    this.page.classList.contains("djacc-screen-reader")
                        ? (this.removeState("sr"),
                          this.page.classList.remove("djacc-screen-reader"),
                          document.querySelectorAll(".djacc-reader").forEach(function (t) {
                              t.classList.remove("djacc-reader");
                          }),
                          speechSynthesis.cancel(),
                          document.body.removeEventListener("click", this.screenReaderEvent, !0),
                          document.body.removeEventListener("focus", this.screenReaderEvent, !0))
                        : (this.addState("sr", "screen-reader"),
                          this.page.classList.add("djacc-screen-reader"),
                          document.body.addEventListener("click", this.screenReaderEvent, !0),
                          document.body.addEventListener("focus", this.screenReaderEvent, !0));
                },
            },
            {
                key: "screenReaderEvent",
                value: function (t) {
                    var e = t.target;
                    if (e) {
                        var n = document.documentElement.getAttribute("lang"),
                            r = e.innerText;
                        if (r) {
                            speechSynthesis.cancel();
                            var a = new SpeechSynthesisUtterance();
                            e.classList.add("djacc-reader"),
                                (a.text = r),
                                n && (a.lang = n),
                                (a.onend = function (t) {
                                    setTimeout(function () {
                                        t.target.accElement.classList.remove("djacc-reader");
                                    }, 500);
                                }),
                                (a.onerror = function (t) {
                                    console.log(t);
                                }),
                                (a.accElement = e),
                                speechSynthesis.speak(a);
                        }
                    }
                },
            },
            {
                key: "updateContrastElements",
                value: function () {
                    var t,
                        e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        n = _createForOfIteratorHelper(this.getNodes());
                    try {
                        for (n.s(); !(t = n.n()).done; ) {
                            var r = t.value;
                            e ? r.classList.add("djacc-contrast") : r.classList.remove("djacc-contrast");
                        }
                    } catch (t) {
                        n.e(t);
                    } finally {
                        n.f();
                    }
                },
            },
            {
                key: "updateLinks",
                value: function () {
                    var t,
                        e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        n = _createForOfIteratorHelper(
                            this.getNodes("links", function (t) {
                                return "A" == t.tagName ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                            })
                        );
                    try {
                        for (n.s(); !(t = n.n()).done; ) {
                            var r = t.value;
                            e ? r.classList.add("djacc-link") : r.classList.remove("djacc-link");
                        }
                    } catch (t) {
                        n.e(t);
                    } finally {
                        n.f();
                    }
                },
            },
            {
                key: "updateTitles",
                value: function () {
                    var t,
                        e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        n = _createForOfIteratorHelper(
                            this.getNodes("titles", function (t) {
                                switch (t.tagName) {
                                    case "H1":
                                    case "H2":
                                    case "H3":
                                    case "H4":
                                    case "H5":
                                        return NodeFilter.FILTER_ACCEPT;
                                    default:
                                        return NodeFilter.FILTER_SKIP;
                                }
                            })
                        );
                    try {
                        for (n.s(); !(t = n.n()).done; ) {
                            var r = t.value;
                            e ? r.classList.add("djacc-title") : r.classList.remove("djacc-title");
                        }
                    } catch (t) {
                        n.e(t);
                    } finally {
                        n.f();
                    }
                },
            },
            {
                key: "countClicks",
                value: function (t, e) {
                    t.classList.contains("djacc__arrows--active") || t.classList.add("djacc__arrows--active"), t.hasAttribute("data-djacc-count") || t.setAttribute("data-djacc-count", 0);
                    var n = t.getAttribute("data-djacc-count"),
                        r = t.querySelector(".djacc__size");        
                    if ("+" === e) {
                        if(n < 10){
                            t.setAttribute("data-djacc-count", ++n);
                            var a = 100 + (n * 10);
                            r.innerHTML = parseInt(a) + "%";
                        }
                    } else {
                        if(n > -10){
                            t.setAttribute("data-djacc-count", --n);
                            var i = 100 + (n * 10);
                            r.innerHTML = parseInt(i) + "%";
                        }
                    }
                    return 0 === n && t.classList.remove("djacc__arrows--active"), t.getAttribute("data-djacc-count");
                
                },
            },
            {
                key: "zoomPage",
                value: function (t) {
                    t = parseInt(t);
                    var e = void 0 !== this.page.style.zoom;
                    if (0 !== t) {
                        var n = 1 + 0.1 * t;
                        (n = parseFloat(n)),
                            this.addState("zoom", t),
                            this.page.classList.add("djacc-zoom"),
                            e ? (this.page.style.zoom = n) : ((this.page.style.transform = "scale(" + n + ")"), (this.page.style.transformOrigin = "center top"));
                    } else this.removeState("zoom"), this.page.classList.remove("djacc-zoom"), e ? (this.page.style.zoom = "") : ((this.page.style.transform = ""), (this.page.style.transformOrigin = ""));
                },
            },
            {
                key: "updateTextStyle",
                value: function (t, e) {
                    var n,
                        r = this.getTextNodes(),
                        a = "data-djacc-" + t,
                        i = "djacc-" + t,
                        c = t;
                    if (
                        (0 === (e = parseInt(e)) ? (this.removeState(t), this.page.classList.remove(i)) : (this.addState(t, e), this.page.classList.add(i)),
                        "font-size" === t ? ((c = "fontSize"), (n = "16px")) : "line-height" === t ? ((c = "lineHeight"), (n = "16px")) : "letter-spacing" === t && ((c = "letterSpacing"), (n = "1px")),
                        r)
                    ) {
                        var o,
                            s = _createForOfIteratorHelper(r);
                        try {
                            for (s.s(); !(o = s.n()).done; ) {
                                var l = o.value;
                                if (!l.hasAttribute(a) && 0 !== e) {
                                    var d = window.getComputedStyle(l).getPropertyValue(t);
                                    l.setAttribute(a, d);
                                }
                                var u = l.getAttribute(a);
                                if (u)
                                    if (e > 0 || e < 0) {
                                        var d=1
                                        if(e < 0){
                                            d=2
                                        }
                                        var h = 1 + 0.1 * e/d,
                                            f = parseFloat(u);
                                        Number.isNaN(f) && (f = parseFloat(n));
                                        var p = (f * h).toFixed(2) + "px";
                                        l.style[c] = p;
                                    } else l.style[c] = u;
                            }
                        } catch (t) {
                            s.e(t);
                        } finally {
                            s.f();
                        }
                    }
                },
            },
            {
                key: "clearContrast",
                value: function () {
                    var t;
                    (this.page.classList.contains("djacc-dark-contrast") || this.page.classList.contains("djacc-light-contrast")) && this.updateContrastElements();
                    (t = this.page.classList).remove.apply(t, ["djacc-invert-colors", "djacc-monochrome", "djacc-low-saturation", "djacc-high-saturation", "djacc-dark-contrast", "djacc-light-contrast"]), (this.page.style.filter = "");
                },
            },
            {
                key: "clearClasses",
                value: function () {
                    var t;
                    this.clearContrast();
                    (t = this.page.classList).remove.apply(t, ["djacc-font-size", "djacc-line-height", "djacc-letter-spacing", "djacc-zoom", "djacc-highlight-links", "djacc-highlight-titles"]);
                },
            },
            {
                key: "getTextNodes",
                value: function () {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "all",
                        e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.body;
                    if (t in this.textNodes) return this.textNodes[t];
                    for (
                        var n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT, function (t) {
                                return "SCRIPT" === t.parentNode.tagName || "STYLE" === t.parentNode.tagName ? NodeFilter.FILTER_SKIP : t.parentNode.closest(".djacc-container") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
                            }),
                            r = [];
                        n.nextNode();

                    ) {
                        var a = n.currentNode;
                        a.textContent.replace(/(\r\n|\n|\r|\t)/gm, "").trim().length && r.push(a.parentNode);
                    }
                    return (this.textNodes[t] = r), r;
                },
            },
            {
                key: "getNodes",
                value: function () {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "all",
                        e = arguments.length > 1 ? arguments[1] : void 0;
                    if (t in this.nodes) return this.nodes[t];
                    e ||
                        (e = function (t) {
                            return 3 === t.nodeType || 8 === t.nodeType ? NodeFilter.FILTER_SKIP : t.closest(".djacc-container") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
                        });
                    for (var n = document.createTreeWalker(document.body, NodeFilter.SHOW_ALL, e), r = []; n.nextNode(); ) {
                        var a = n.currentNode;
                        r.push(a);
                    }
                    return (this.nodes[t] = r), r;
                },
            },
            {
                key: "getVersion",
                value: function () {
                    return "dmVyc2lvbnBybw==" === this.options.version;
                },
            },
            {
                key: "setVersion",
                value: function () {
                    "dmVyc2lvbnBybw==" !== this.options.version && (document.querySelector(".djacc__btn.djacc__btn--read-mode").remove(), document.querySelector(".djacc__btn.djacc__btn--screen-reader").remove());
                },
            },
            {
                key: "saveCookie",
                value: function (t) {
                    this.setCookie("dj-acc-cookie", JSON.stringify(t));
                },
            },
            {
                key: "removeCookie",
                value: function () {
                    this.deleteCookie("dj-acc-cookie");
                },
            },
            {
                key: "getCookie",
                value: function () {
                    return document.cookie.split("; ").reduce(function (t, e) {
                        var n = e.split("=");
                        return "dj-acc-cookie" === n[0] ? decodeURIComponent(n[1]) : t;
                    }, "");
                },
            },
            {
                key: "setCookie",
                value: function (t, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 30,
                        r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "/",
                        a = new Date(Date.now() + 864e5 * n).toUTCString();
                    document.cookie = t + "=" + encodeURIComponent(e) + "; expires=" + a + "; path=" + r;
                },
            },
            {
                key: "deleteCookie",
                value: function (t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/";
                    this.setCookie(t, "", -1, e);
                },
            },
        ]),
        t
    );
})();
